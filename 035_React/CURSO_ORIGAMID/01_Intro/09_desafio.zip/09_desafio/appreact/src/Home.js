import React from 'react'

const Home = props => {
    return (
        <div>
            <h1>
                Home
            </h1>
            <p>
                Escolha um link para acessar
            </p>
        </div>
    )
}

export default Home