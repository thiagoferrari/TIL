import React from 'react'

const Header = props => {
    return (
        <>
            <div><a href='/' >Home</a></div>
            <div><a href='/Produtos' >Produtos</a></div>
        </>
    )
}

export default Header