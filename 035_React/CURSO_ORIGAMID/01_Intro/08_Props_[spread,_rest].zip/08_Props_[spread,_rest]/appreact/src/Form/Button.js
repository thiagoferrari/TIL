import React from 'react'

const Button = () => {
    return (
        <div>
            <button >
                Clique
            </button>
        </div>
    )
}

export default Button